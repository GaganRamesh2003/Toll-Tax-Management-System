<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
$vname=$_GET['editid'];
$ret=mysqli_query($con,"delete from contacthome where name='$vname'");

 if ($ret) {
     echo '<script>alert("feedback Deleted")</script>';
echo "<script>window.location.href ='feedback-messages.php'</script>";
  }
  else
    {
      echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
	
?>