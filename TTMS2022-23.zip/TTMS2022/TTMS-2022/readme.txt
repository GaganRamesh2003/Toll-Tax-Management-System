How to run the Toll Tax Management System (TTMS)

1. Open Xampp control Panel
2. Start "Apache" & "MySQL"
3.Open Any Web Browser and Type :- http://localhost/TTMS
4. Use Below Credential to Login

Login Detail for admin
Username : admin
Password: Test@123

Login Details for Satff
Username : rajat@gmail.com
Password: 123456