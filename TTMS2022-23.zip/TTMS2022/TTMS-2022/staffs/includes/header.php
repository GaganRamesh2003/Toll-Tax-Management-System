<nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">TTMS</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
     
          <li class="dropdown">
              <a href="#" class="dropdown-toggle avatar" data-toggle="dropdown"><img src="images/image.png"><span class="badge"></span></a>
              <ul class="dropdown-menu">
           
          
            <li class="m_2"><a href="staff-profile.php"><i class="fa fa-user"></i> Profile</a></li>
            <li class="m_2"><a href="change-password.php"><i class="fa fa-wrench"></i> Settings</a></li>
            
            <li class="m_2"><a href="logout.php"><i class="fa fa-lock"></i> Logout</a></li>  
              </ul>
            </li>
      </ul>
      
            </nav>