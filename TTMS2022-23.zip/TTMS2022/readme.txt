How to run the Toll Tax Management System (ttms)
1. Copy the zip file

2. Extract the file and copy ttms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name ttmsdb

6. Import ttmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/TTMS-2021

Login Detail for admin
Username : admin
Password: Test@123

Login Details for Satff
Username : test@gmail.com
Password: Test@123